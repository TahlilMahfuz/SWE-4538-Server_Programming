const express = require("express");
const router = express.Router();
const {
    getHobbyPage,
    createHobby,
    deleteHobby,
    getProfilesbyHobby,
    updateHobby,
} = require("../controllers/hobby.controllers");

router.get('/createHobby', getHobbyPage);
router.post('/createHobby', createHobby);
router.delete('/deleteHobby/:name', deleteHobby);
router.get('/getProfilesbyHobby', getProfilesbyHobby);
router.patch("/updateHobby/:name/:description",updateHobby);

module.exports = router;